
#ifndef __SNAILMAIL_HOUSE_H_
#define __SNAILMAIL_HOUSE_H_

#include <omnetpp.h>

using namespace omnetpp;

class House : public cSimpleModule
{
  protected:

    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

};

#endif

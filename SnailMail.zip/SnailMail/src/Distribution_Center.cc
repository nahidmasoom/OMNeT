
#include "Distribution_Center.h"

Define_Module(Distribution_Center);

void Distribution_Center::initialize()
{
    // TODO - Generated method body
}

void Distribution_Center::handleMessage(cMessage *msg)
{
    // find out which village
    int Village = msg->par("destVillage");

    // get a pointer to the out gate
    cGate *where = gate("Distribution_Center_gate$o", Village);

    // send it out
    send(msg, where);

}

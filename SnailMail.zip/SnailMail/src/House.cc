
#include "House.h"

Define_Module(House);

void House::initialize()
{
    int houses = getParentModule() -> par("numHouses");
    int villages = getParentModule() -> getParentModule() -> par("numVillages");

    EV << "We have " << houses << " houses per village and " << villages << " villages.\n";

    int destVil = intuniform(0, villages - 1);  // Selection of the village randomly
    int destHouse = intuniform(0, houses - 1);  // Selection of the house randomly

    int sourceVil = getParentModule() -> par("villageID");
    int sourceHouse = par("houseID");

    cMessage *letter1 = new cMessage("Original");
    letter1 -> addPar("destVillage");
    letter1 -> par("destVillage") = destVil;
    letter1 -> addPar("destHouse");
    letter1 -> par("destHouse") = destHouse;

    letter1 -> addPar("sourceVillage");
    letter1-> par("sourceVillage") = sourceVil;
    letter1-> addPar("sourceHouse");
    letter1-> par("sourceHouse") = sourceHouse;
    letter1-> addPar("Acknowledgment");
    letter1-> par("Acknowledgment") = false;

    sendDelayed(letter1, 50, "gate$o");

}

void House::handleMessage(cMessage *msg)
{
      if (msg -> isSelfMessage())
      {
          EV << "Self-timers are currently not in use, stop simulation.\n";
          endSimulation();
      }
      if (((int)msg -> par("destVillage") == (int)getParentModule() -> par("villageID")) && ((int)msg -> par("destHouse") == (int)par("houseID")))
      {
          if ((bool)msg -> par("Acknowledgment"))
          {
              EV<<"Sending acknowledgment\n";

              delete msg;
          }
          else
          {
              EV << "Letter received\n";

              cMessage *letter2 = new cMessage("Reply");
              letter2 -> addPar("destHouse");
              letter2 -> par("destHouse") = (int)msg -> par("sourceHouse");

              letter2 -> addPar("Acknowledgment");
              letter2 -> par("Acknowledgment") = true;

              letter2 -> addPar("destVillage");
              letter2 -> par("destVillage") = (int)msg -> par("sourceVillage");

              int delay = intuniform(1, 7); // Random delay between 1 and 7 days

              sendDelayed(letter2, delay * 24 * 60 * 60, "gate$o");

          }

      }

}
